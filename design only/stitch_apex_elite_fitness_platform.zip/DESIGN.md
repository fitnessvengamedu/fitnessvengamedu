---
name: Kinetic Onyx
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#c5c9ac'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#8f9378'
  outline-variant: '#444932'
  surface-tint: '#b0d500'
  primary: '#ffffff'
  on-primary: '#2a3400'
  primary-container: '#caf300'
  on-primary-container: '#596c00'
  inverse-primary: '#536600'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#4a4949'
  on-secondary-container: '#bab8b7'
  tertiary: '#ffffff'
  on-tertiary: '#1b343d'
  tertiary-container: '#cde7f3'
  on-tertiary-container: '#506873'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#caf300'
  primary-fixed-dim: '#b0d500'
  on-primary-fixed: '#171e00'
  on-primary-fixed-variant: '#3e4c00'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#cde7f3'
  tertiary-fixed-dim: '#b1cad7'
  on-tertiary-fixed: '#041e28'
  on-tertiary-fixed-variant: '#324a54'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  surface-elevated: '#1E1E1E'
  text-primary: '#FFFFFF'
  text-secondary: '#A1A1AA'
  electric-lime: '#D4FF00'
  deep-charcoal: '#121212'
  pure-black: '#0A0A0A'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Montserrat
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-padding: 80px
---

## Brand & Style
This design system is built for a premium, high-performance fitness environment. It communicates discipline, strength, and exclusivity through a "Midnight High-Contrast" aesthetic.

The visual narrative focuses on **Minimalism** and **High-Contrast** elements. By using a monochromatic base of deep charcoals and blacks, we allow professional fitness photography and a singular high-energy accent color to command immediate attention. The style is unapologetically bold and modern, evoking a sense of focus and elite athleticism.

## Colors
The palette is rooted in a deep dark theme to minimize distractions and maximize visual impact.

- **Backgrounds:** Use `#0A0A0A` for the primary canvas and `#121212` for secondary sections or containers to create subtle depth.
- **Primary Accent:** `Electric Lime (#D4FF00)` is the high-energy pulse of the UI. It is used exclusively for primary actions, progress indicators, and critical highlights.
- **Neutral Tones:** Pure whites and light grays are reserved for typography to ensure AA+ accessibility against the dark backdrop.

## Typography
The typography system uses a pairing of **Montserrat** for headlines and **Inter** for body and UI elements.

- **Headlines:** Set in Montserrat with heavy weights (700-800) and tight letter-spacing for a powerful, "industrial" feel.
- **Body:** Inter provides exceptional legibility. The minimum size is set to 16px to ensure readability during active workouts.
- **Labels:** Small caps and bold weights are used for data points (e.g., heart rate, reps, sets) to distinguish them from prose.

## Layout & Spacing
The design system utilizes a **Fixed Grid** model on desktop (12 columns) and a **Fluid Grid** on mobile (4 columns).

- **Generous Whitespace:** Section spacing is intentionally large (80px+) to allow the high-contrast imagery to breathe.
- **Rhythm:** An 8px linear scale governs all padding and margins.
- **Reflow:** On mobile, side margins reduce to 16px, and multi-column grids collapse into a single vertical stack to maintain focus.

## Elevation & Depth
Depth is achieved through **Tonal Layers** rather than heavy drop shadows, maintaining a clean and modern profile.

- **Base (Level 0):** `#0A0A0A` - The primary app background.
- **Surface (Level 1):** `#121212` - Used for cards and secondary containers.
- **Overlay (Level 2):** `#1E1E1E` - Used for modals and floating elements.
- **Shadows:** Use a single, very soft ambient shadow for Level 2 elements: `0px 10px 30px rgba(0, 0, 0, 0.5)`. This creates a subtle lift without breaking the minimalist aesthetic.

## Shapes
The shape language is disciplined and precise.

- **Corner Radii:** A consistent `8px` (standard) to `12px` (large containers) radius is applied. This softens the aggressive high-contrast colors just enough to feel "premium" rather than "hostile."
- **Buttons:** Follow the standard 8px radius.
- **Interactive States:** Hover states should involve a subtle scale increase (1.02x) rather than changing the border-radius.

## Components
- **Buttons:**
    - **Primary:** Background `Electric Lime`, Text `Pure Black`, Bold weight.
    - **Secondary:** Outlined with `White` (2px), Text `White`.
- **Cards:** Use `#121212` background with an 8px radius. Images within cards should have high-contrast filters or subtle dark overlays to ensure text legibility.
- **Inputs:** Dark background (`#1E1E1E`) with a 1px border. The border turns `Electric Lime` only on focus.
- **Chips/Badges:** Small, high-contrast labels for "New Workout" or "Pro" status, using the `label-bold` typography style.
- **Progress Bars:** Thin tracks using `#1E1E1E` with a high-visibility `Electric Lime` fill.